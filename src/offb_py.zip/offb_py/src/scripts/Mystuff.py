#!/usr/bin/env python

# MAVROS Offboard control example
# (https://dev.px4.io/en/ros/mavros_offboard.html)
#
#     >>> translated from C++ to Python


'''
The mavros_msgs package contains 
all of the custom messages required 
to operate services and topics provided 
by the MAVROS package. All services and 
topics as well as their corresponding 
message types are documented in the 
mavros wiki (http://wiki.ros.org/mavros).
'''

import rospy
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import TwistStamped
from mavros_msgs.srv import CommandBool
from mavros_msgs.srv import SetMode
from mavros_msgs.msg import State

'''
We create a simple callback which will
save the current state of the autopilot. 
This will allow us to check connection, 
arming and Offboard flags.
'''

current_state = State()

def state_cb(msg):
	global current_state
	current_state = msg
	#print "callback"


if __name__=="__main__":

	# global current_state

    # We instantiate a publisher to publish 
    # the commanded local position and the 
    # appropriate clients to request arming
    # and mode change. Note that for your own 
    # system, the "mavros" prefix might be 
    # different as it will depend on the name 
    # given to the node in it's launch file.

	rospy.init_node('offb_node', anonymous=True)	
	rospy.Subscriber("mavros/state", State, state_cb)
	local_pos_pub = rospy.Publisher('mavros/setpoint_position/local', PoseStamped, queue_size=10)
	local_vel_pub = rospy.Publisher('mavros/setpoint_velocity/cmd_vel', TwistStamped, queue_size=10)

	print("Publisher and Subscriber Created")
	arming_client = rospy.ServiceProxy('mavros/cmd/arming', CommandBool)
	set_mode_client = rospy.ServiceProxy('mavros/set_mode', SetMode)
	print("Clients Created")

    # The px4 flight stack has a timeout of 500ms 
    # between two Offboard commands. If this timeout 
    # is exceeded, the commander will fall back to 
    # the last mode the vehicle was in before entering 
    # Offboard mode. This is why the publishing rate 
    # must be faster than 2 Hz to also account for 
    # possible latencies. This is also the same reason 
    # why it is recommended to enter Offboard mode 
    # from Position mode, this way if the vehicle 
    # drops out of Offboard mode it will stop in 
    # its tracks and hover.

	rate = rospy.Rate(20)

    # Before publishing anything, we wait for the connection
    # to be established between MAVROS and the autopilot. 
    # This loop should exit as soon as a heartbeat message is received.
	
	while(not current_state.connected):
		print(current_state.connected)
		rate.sleep()

    # Even though the PX4 Pro Flight Stack operates in the 
    # aerospace NED coordinate frame, MAVROS translates 
    # these coordinates to the standard ENU frame and vice-versa. 
    # This is why we set z to positive 2.

	print("Creating pose")
	pose = PoseStamped()
	#set position here
	pose.pose.position.x = 0
	pose.pose.position.y = 0
	pose.pose.position.z = 2

	#vel = TwistStamped()
	#vel.linear.x = 20
	#vel.linear.y = 20
	#vel.linear.z = 20

    # Before entering Offboard mode, you must have already 
    # started streaming setpoints. Otherwise the mode switch 
    # will be rejected. Here, 100 was chosen as an arbitrary amount.
	
	for i in range(100):
		local_pos_pub.publish(pose)
		rate.sleep()

    # We set the custom mode to OFFBOARD. 
    # A list of supported modes is available for reference.
    # (http://wiki.ros.org/mavros/CustomModes#PX4_native_flight_stack)
		
	print("Creating Objects for services")
	offb_set_mode = SetMode()
	offb_set_mode.custom_mode = "OFFBOARD"

    # The rest of the code is pretty self explanatory. 
    # We attempt to switch to Offboard mode, 
    # after which we arm the quad to allow it to fly. 
    # We space out the service calls by 5 seconds 
    # so to not flood the autopilot with the requests. 
    # In the same loop, we continue sending the requested 
    # pose at the appropriate rate.

	arm_cmd = CommandBool()
	arm_cmd.value = True
	
	last_request = rospy.Time.now()
	
	while not rospy.is_shutdown():
		#print(current_state)
		if(current_state.mode != "OFFBOARD" and (rospy.Time.now() - last_request > rospy.Duration(5.0))):
			resp1 = set_mode_client(0,offb_set_mode.custom_mode)
			if resp1.mode_sent:
				print ("Offboard enabled")
			last_request = rospy.Time.now()
		elif (not current_state.armed and (rospy.Time.now() - last_request > rospy.Duration(5.0))):
			arm_client_1 = arming_client(arm_cmd.value)
			if arm_client_1.success:
				print("Vehicle armed")
			last_request = rospy.Time.now()
			
		local_pos_pub.publish(pose)
		#local_vel_pub.publish(vel)
		#print current_state
		rate.sleep()