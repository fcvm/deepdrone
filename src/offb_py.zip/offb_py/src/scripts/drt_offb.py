#!/usr/bin/env python
# -*- coding: utf-8 -*-



'____ TO DO ____'

# - 

'____ \TO DO ____'



'____ IMPORT ____'
# Generic modules
#import os; dirname = os.path.dirname(__file__)
#import sys
#import numpy as np
#from scipy.spatial.transform import Rotation
# ROS packages
import rospy
from geometry_msgs.msg import PoseStamped, TwistStamped
from mavros_msgs.srv import CommandBool
from mavros_msgs.srv import SetMode
from mavros_msgs.msg import State
# Own scripts
#from ___ import *
'____ \IMPORT ____'



'____ CLASS ____'
class TrajPublisher( ):
    def __init__( self ):
        self.cur_state = State()

        rospy.init_node('TrajPublisher', anonymous=True)	
        rospy.Subscriber('mavros/state', State, self.UpdState)
        local_pos_pub = rospy.Publisher('mavros/setpoint_position/local', PoseStamped, queue_size=10)
        local_vel_pub = rospy.Publisher('mavros/setpoint_velocity/cmd_vel', Twist, queue_size=10)
        print("Publisher and Subscriber Created")
        
        arming_client = rospy.ServiceProxy('mavros/cmd/arming', CommandBool)
	    set_mode_client = rospy.ServiceProxy('mavros/set_mode', SetMode)
	    print("Clients Created")
	    rate = rospy.Rate(20)

        while(not current_state.connected):
		    print(current_state.connected)
		    rate.sleep()

    def UpdState( state ):
        self.cur_state = state

'____ \CLASS ____'



'____ MAIN ____'
if __name__ == "__main__":
    listen()
'____ \MAIN ____'